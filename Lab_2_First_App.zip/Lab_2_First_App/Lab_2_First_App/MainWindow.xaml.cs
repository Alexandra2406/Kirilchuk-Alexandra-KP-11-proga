﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Linq;
using System.Diagnostics;
using System.IO;

namespace Lab_2_First_App
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static DispatcherTimer dT;
        static int Radius = 20;
        static int PointCount = 5;
        static int maxIterations, maxPopulation;
        static double mutationChance;
        static string algoritm;
        static Polygon myPolygon = new Polygon();
        static List<Ellipse> EllipseArray = new List<Ellipse>();
        static PointCollection pC = new PointCollection();
        static PointCollection pC1 = new PointCollection();
        Random rnd = new Random();
        bool flag = true;
        bool flag1 = false;

        public MainWindow()
        {
            dT = new DispatcherTimer();

            InitializeComponent();
            InitPoints();
            InitPolygon();

            dT = new DispatcherTimer();
            dT.Tick += new EventHandler(OneStep);
            dT.Interval = new TimeSpan(0, 0, 0, 0, 300);
        }
        
        private void InitPoints()
        {
            pC.Clear();
            EllipseArray.Clear();

            for (int i = 0; i < PointCount; i++)
            {
                Point p = new Point();

                p.X = rnd.Next(Radius, (int)(0.75 * MainWin.Width - 2 * Radius));
                p.Y = rnd.Next(Radius, (int)(0.75 * MainWin.Height - 2 * Radius));
                pC.Add(p);
            }

            for (int i = 0; i < PointCount; i++)
            {
                Ellipse el = new Ellipse();

                el.StrokeThickness = 2;
                el.Height = el.Width = Radius;
                el.Stroke = Brushes.Black;
                el.Fill = Brushes.LightBlue;
                EllipseArray.Add(el);
            }
        }

        private void InitPolygon()
        {
            myPolygon.Stroke = Brushes.Black;
            myPolygon.StrokeThickness = 2;
        }

        private void PlotPoints()
        {
            for (int i = 0; i < PointCount; i++)
            {
                Canvas.SetLeft(EllipseArray[i], pC[i].X - Radius / 2);
                Canvas.SetTop(EllipseArray[i], pC[i].Y - Radius / 2);
                MyCanvas.Children.Add(EllipseArray[i]);
            }
        }


        private void PlotWay(int[] BestWayIndex)
        {
            PointCollection Points = new PointCollection();
            Points.Clear();
            for (int i = 0; i < BestWayIndex.Length; i++)
                Points.Add(pC[BestWayIndex[i]]);

            myPolygon.Points = Points;
            MyCanvas.Children.Add(myPolygon);
        }
        static List<int> Way = new List<int>();
     

        private void StopStart_Click(object sender, RoutedEventArgs e)
        {
            if (dT.IsEnabled)
            {
                dT.Stop();
                NumElemCB.IsEnabled = true;
                MaxI.IsEnabled = true;
                M.IsEnabled = true;
                PopSize.IsEnabled = true;
                Algoritm.IsEnabled = true;
            }
            else
            {
                NumElemCB.IsEnabled = false;
                MaxI.IsEnabled = false;
                M.IsEnabled = false;
                PopSize.IsEnabled = false;
                Algoritm.IsEnabled = false;
                dT.Start();
            }
        }

        private void NumElemCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox CB = (ComboBox)e.Source;
            ListBoxItem item = (ListBoxItem)CB.SelectedItem;

            PointCount = Convert.ToInt32(item.Content);
            InitPoints();
            InitPolygon();

            flag = true;
        }
        private void PopSise_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox CB = (ComboBox)e.Source;
            ListBoxItem item = (ListBoxItem)CB.SelectedItem;

            maxPopulation = Convert.ToInt32(item.Content);
            InitPoints();
            InitPolygon();
        }
        private void M_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox CB = (ComboBox)e.Source;
            ListBoxItem item = (ListBoxItem)CB.SelectedItem;
            
            mutationChance = Convert.ToDouble(item.Content);
            InitPoints();
            InitPolygon();
        }
        private void MaxI_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox CB = (ComboBox)e.Source;
            ListBoxItem item = (ListBoxItem)CB.SelectedItem;

            maxIterations = Convert.ToInt32(item.Content);
            InitPoints();
            InitPolygon();
        }
        private void Algoritm_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox CB = (ComboBox)e.Source;
            ListBoxItem item = (ListBoxItem)CB.SelectedItem;

            algoritm = Convert.ToString(item.Content);
            InitPoints();
            InitPolygon();
        }
        int q = 0;
        private void OneStep(object sender, EventArgs e)
        {
           
            MyCanvas.Children.Clear();
            //InitPoints();
            PlotPoints();
            if (algoritm == "Greedy") 
            { 
                if (q == 0)
                    PlotWay(GetBestWay_Greedy()); 
                else
                { 
                    PlotWay(way);
                    q = 1;
                }                 
            }
            else if (algoritm == "Random") 
            { 
                flag1 = true; 
                PlotWay(RandomWay()); 
            }
            else if (algoritm == "Genetic")
            {    
                if (q <= maxIterations)
                {
                    if(q % 10 == 0 && q!= 0)
                        myPolygon.Stroke = Brushes.Red;
                    else
                        myPolygon.Stroke = Brushes.Black;
                    q += 1;
                    PlotWay(Genetic());
                    StreamWriter FileGenetic = File.AppendText("FileGenetic.txt");
                    FileGenetic.WriteLine(GetLength(BestWay));
                    FileGenetic.Close();    
                    
                }
                else
                {
                    File.WriteAllText("FileGenetic.txt", string.Empty);
                    PlotWay(BestWay);
                    flag = true;
                   
                }
            }
        }

        private int[] RandomWay()
        {
            int[] way = new int[PointCount];
            for (int i = 0; i < PointCount; i++)
                way[i] = i;
            for (int s = 0; s < 2 * PointCount; s++)
            {
                int i1, i2, tmp;

                i1 = rnd.Next(PointCount);
                i2 = rnd.Next(PointCount);
                tmp = way[i1];
                way[i1] = way[i2];
                way[i2] = tmp;
            }
            if(flag1)
            Length.Content = Math.Round(GetLength(way));
            return way;
        }

        public static int[] BestWay = new int[PointCount];
        List<int[]> Population = new List<int[]>();

        private int[] Genetic()
        {         
            if (flag)
            {
                Population.Clear();
                for (int i = 0; i <= maxPopulation; i++)
                    Population.Add(RandomWay());
                flag = false;
            }

            int[] r, r1 = new int[PointCount];

            for (int j = 0; j < maxPopulation; j++)
            {
                int RandomIndex1 = rnd.Next(maxPopulation);
                int RandomIndex2 = rnd.Next(maxPopulation);

                int[] f1 = Population[RandomIndex1];
                int[] f2 = Population[RandomIndex2];

                int b = rnd.Next(1, PointCount - 1);

                if (rnd.NextDouble() < 0.5)
                    r = f1.ToList().GetRange(0, b).Union(f2.ToList().GetRange(b, f2.Length - b)).Union(f1.ToList().GetRange(b, f1.Length - b)).ToArray();
                else
                    r = f2.ToList().GetRange(0, b).Union(f1.ToList().GetRange(b, f1.Length - b)).Union(f2.ToList().GetRange(b, f2.Length - b)).ToArray();

                int g = rnd.Next(1, r.Length - 1);
                int h = rnd.Next(1, r.Length - 1);
                var list = r.ToList();
                if (rnd.NextDouble() < mutationChance)
                {
                    if (g <= h)
                        list.Reverse(g, h - g);
                    else
                        list.Reverse(h, g - h);
                    r1 = list.ToArray();
                    r = r1;
                }
                Population.Add(r);
            }
            Population = Population.OrderBy(t => GetLength(t)).ToList();
            Population.RemoveRange(maxPopulation, maxPopulation);

            BestWay = Population[0];
            Length.Content = Math.Round(GetLength(BestWay));

            return BestWay;
        }

        private double GetLength(int[] l)
        {
            double len = 0;

            for (int i = 0; i < l.Length; i++)
            {
                if (i < l.Length - 1)
                    len += Math.Sqrt(Math.Pow((pC[l[i]].X - pC[l[i + 1]].X), 2) +
                                     Math.Pow((pC[l[i]].Y - pC[l[i + 1]].Y), 2));
                else
                    len += Math.Sqrt(Math.Pow((pC[l[i]].X - pC[l[0]].X), 2) +
                                     Math.Pow((pC[l[i]].Y - pC[l[0]].Y), 2));
            }

            return len;
        }


        int[] way;
        private int[] GetBestWay_Greedy()
        {
            way = new int[PointCount];
            List<int> freepoints = new List<int>();
            for (int i = 1; i < PointCount; i++)
            {
                freepoints.Add(i);
            }
            int k = 0;
            way[0] = k;
            int p = 0;
            for (int i = 1; i < PointCount; i++)
            {
                p = k;
                k = FindMin(freepoints, p);
                freepoints.Remove(k);
                way[i] = k;
            }
            Length.Content = Math.Round(GetLength(way));
            return way;
        }

        static int FindMin(List<int> freepoints, int k)
        {
            int p = 0;
            double[] len = new double[freepoints.Count];
            double min = double.MaxValue;
            for (int i = 0; i < freepoints.Count; i++)
            {
                len[i] = Math.Sqrt(Math.Pow((pC[freepoints[i]].X - pC[k].X), 2) + Math.Pow((pC[freepoints[i]].Y - pC[k].Y), 2));
                if (len[i] < min)
                {
                    min = len[i];
                    p = freepoints[i];
                }
            }
            return p;
        }
        

    }
}
